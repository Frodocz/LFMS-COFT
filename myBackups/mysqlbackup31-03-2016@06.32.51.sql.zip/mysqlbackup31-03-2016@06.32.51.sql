--
-- Database : DB_NAME
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `admin_user`
--
DROP TABLE  IF EXISTS `admin_user`;
CREATE TABLE `admin_user` (
  `username` char(32) DEFAULT NULL,
  `password` char(32) DEFAULT NULL,
  `identity` varchar(10) NOT NULL,
  `admin_name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `admin_user`  VALUES ( "admintest1@test.com","admintest1","admin","Zhang Chao");
INSERT INTO `admin_user`  VALUES ( "frodocz1226@gmail.com","19921226","admin","Zhang Chao");


--
-- Tabel structure for table `announcement`
--
DROP TABLE  IF EXISTS `announcement`;
CREATE TABLE `announcement` (
  `noti_id` int(11) NOT NULL AUTO_INCREMENT,
  `announcement` text NOT NULL,
  `noti_date` date NOT NULL,
  PRIMARY KEY (`noti_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `announcement`  VALUES ( "1","Dear users, a new facility \"Testing Facility 1\" is available for booking and visiting now. ","2016-03-31");


--
-- Tabel structure for table `bill_list`
--
DROP TABLE  IF EXISTS `bill_list`;
CREATE TABLE `bill_list` (
  `bill_id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` int(11) NOT NULL,
  `billtime` int(11) NOT NULL,
  PRIMARY KEY (`bill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `booking_list`
--
DROP TABLE  IF EXISTS `booking_list`;
CREATE TABLE `booking_list` (
  `booking_id` int(11) NOT NULL AUTO_INCREMENT,
  `facility_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `starttime` int(11) NOT NULL,
  `endtime` int(11) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `hourdiff` decimal(10,1) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `approved` tinyint(1) NOT NULL,
  `billed` tinyint(1) NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO `booking_list`  VALUES ( "1","1","2","book","1458869400","1458876600","#378006","2.0","320.00","1","1");
INSERT INTO `booking_list`  VALUES ( "3","6","2","book","1458871200","1458880200","#378006","2.5","300.00","1","1");
INSERT INTO `booking_list`  VALUES ( "5","3","2","visit","1458869400","1458880200","#115599","3.0","0.00","1","0");
INSERT INTO `booking_list`  VALUES ( "6","6","2","visit","1458880200","1458885600","#378006","1.5","0.00","1","0");
INSERT INTO `booking_list`  VALUES ( "7","5","2","book","1459299600","1459308600","#378006","2.5","100.00","1","1");
INSERT INTO `booking_list`  VALUES ( "8","5","2","book","1459389600","1459396800","#378006","2.0","80.00","1","1");
INSERT INTO `booking_list`  VALUES ( "19","4","8","book","1459326600","1459332000","#378006","1.5","675.00","1","1");
INSERT INTO `booking_list`  VALUES ( "17","9","9","visit","1459404000","1459407600","#115599","1.0","0.00","1","0");


--
-- Tabel structure for table `facility_list`
--
DROP TABLE  IF EXISTS `facility_list`;
CREATE TABLE `facility_list` (
  `facility_id` int(11) NOT NULL AUTO_INCREMENT,
  `facility_imagename` varchar(100) NOT NULL,
  `facility_imagepath` text NOT NULL,
  `facility_name` varchar(64) NOT NULL,
  `facility_description` text NOT NULL,
  `facility_internal_price` decimal(11,2) NOT NULL,
  `facility_external_price` decimal(11,2) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `description` varchar(32) NOT NULL,
  PRIMARY KEY (`facility_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `facility_list`  VALUES ( "1","FDT.jpg","facilities/FDT.jpg","Fibre Draw Tower","The first Fibre Draw Tower in Singapore is 8.5m tall and comes with two sides capable of pulling fibres at a rate of up to 200m/min. Side 1 is equipped with a graphite resistance furnace that is able to cover temperatures up to 2500 C for drawing of silica fibres from preforms with diameters ranging from <5mm to 30mm. Side 2 comes equipped with an interchangeable graphite resistance furnace and softglass furnace, capable of drawing silica canes/capillaries and softglass (chalcogenide, fluoride, heavy metal oxide and tellurite) fibres respectively.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ","160.00","200.00","1","Working Well");
INSERT INTO `facility_list`  VALUES ( "2","MCVD.jpg","facilities/MCVD.jpg","MCVD Lathe","COFT fabricates its silica preforms by MCVD, which involves the deposition of glass particles on the inside wall of a substrate tube using gaseous reactions at high temperatures, according to the desired refractive index profile of the final fibre. The tube is subsequently collapsed into a rod, which is the precursor of the fibre cladding and core structure.                                                                                                                                                ","100.00","150.00","0","Under Maintenance");
INSERT INTO `facility_list`  VALUES ( "3","PK2610.jpg","facilities/PK2610.jpg","PK2610 - Preform Index Profiler","The PK2610 preform index profiler is used to measure the refractive index of preforms fabricated by the MCVD process at COFT. The profiler is equipped with an automatic preform tip location system and has the capability of performing slice as well as helix measurements of a preform.                                                                                                                               ","130.00","170.00","1","Working Well");
INSERT INTO `facility_list`  VALUES ( "4","PTRM.jpg","facilities/PTRM.jpg","Proof Tester and Rewinding Machine","This machine is designed to test the tension of the fibres drawn at COFT. It can also be used for rewinding fibres from a big reel on the draw tower to a small international standard reel.                   ","450.00","450.00","1","Working Well");
INSERT INTO `facility_list`  VALUES ( "5","GWL.jpg","facilities/GWL.jpg","Glass Working Lathe","The SG Controls Glass Working Lathe is used to perform all glass working processes related to preform fabrication. Some of the processes include preform sleeving, stretching and fire polishing.                  ","40.00","50.00","1","Working Well");
INSERT INTO `facility_list`  VALUES ( "6","FIP.jpg","facilities/FIP.jpg","IFA-100 - Fibre Index Profiler","The IFA-100 Fibre Index Profiler is used to determine the refractive index profile of fibres drawn from the Fibre Draw Tower. This equipment is capable of carrying out 1-D and 2-D index profile measurements, as well measuring the residual stress in a fibre by measuring the refractive index at 2 orthogonal polarisations.                  ","120.00","160.00","1","Working Well");
INSERT INTO `facility_list`  VALUES ( "7","GPS.jpg","facilities/GPS.jpg","LZM-100 - Glass Processing Station","The LZM-100 Glass Processing Station makes use of a CO2 laser heat source to perform a wide range of glass working processes on fabricated fibres. These processes include: large diameter (400um) fibre splicing, photonic-crystal fibre (PCF) alignment and splicing, fibre tapering, ball lensing, fibre coupling and making of fibre combiners.                                                                                                            ","75.00","100.00","1","Working Well");
INSERT INTO `facility_list`  VALUES ( "9","logo2.png","facilities/logo2.png","Testing Facility 1","This the the description of Testing Facility 1. Testing here!!!","20.00","30.00","1","Working Well");


--
-- Tabel structure for table `normal_user`
--
DROP TABLE  IF EXISTS `normal_user`;
CREATE TABLE `normal_user` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) DEFAULT NULL,
  `identity` varchar(10) NOT NULL,
  `title` varchar(20) NOT NULL,
  `name` varchar(32) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `addressline1` varchar(64) NOT NULL,
  `addressline2` varchar(64) NOT NULL,
  `postal` varchar(6) NOT NULL,
  `faculty` varchar(64) NOT NULL,
  `registerdate` date NOT NULL,
  `facility_access` text NOT NULL,
  `approved` tinyint(1) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `normal_user`  VALUES ( "2","normaltest1@test.com","4a81a679f524e1528775c9663e168d68","normal","Mr.","Zhang Chao","+65-85800225","19 Jurong West Avenue 5","#05-40","649492","EEE/NTU","2016-01-24","Fibre Draw Tower,MCVD Lathe,PK2610 - Preform Index Profiler,Proof Tester and Rewinding Machine,Glass Working Lathe,IFA-100 - Fibre Index Profiler,LZM-100 - Glass Processing Station","1");
INSERT INTO `normal_user`  VALUES ( "5","wanyuan@test.com","4a057be373e63077763ec0b53cf8100a","normal","Mr.","Wan Yuan","85800150","34 Nanyang Crescent","67-2-1393","649492","EEE","2016-02-22","","0");
INSERT INTO `normal_user`  VALUES ( "8","qiaozhi@test.com","4a057be373e63077763ec0b53cf8100a","normal","Ms.","Song Qiaozhi","85800225","34 Nanyang Crescent","72-3","637634","EEE","2016-02-24","Proof Tester and Rewinding Machine","1");
INSERT INTO `normal_user`  VALUES ( "9","normaltest2@test.com","85b68e9d03c2396337d014e3dc42876a","normal","Ms.","Wang Zirui","+65-98074046","34 Nanyang Crescent","67-2-1393","639809","IEM","2016-03-16","Fibre Draw Tower","1");


SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
